<?php $__env->startSection('title', 'Buy - '.$search_tags); ?>
<?php echo $__env->make('ecom-layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="row mb-5">
        <div class="col-md-12 text-center filter-type-holder">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 fw-bold">
                <?php if(Menus()): ?>
                <?php $__currentLoopData = Menus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('tags', ['name' => $menu->menu])); ?>"><?php echo e(ucfirst($menu->menu)); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Menu</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</section>


<header class="container my-5">
    <img src="https://oo-prod.s3.amazonaws.com/public/artworks/2019/03/28/63d39126738c76ac/original.jpg" alt=""
        class="img-fluid">
</header>
<section class="container my-5">

    <h5 class="mb-3">Shop Top - <?php echo e($search_tags); ?></h5>

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-2">
            <div class="bg-white rounded p-2 single-product">
                <a href="<?php echo e('/details/'.$product->id); ?>" class="text-decoration-none ">
                    <img src="<?php echo e(asset($product->default_front_image)); ?>" alt="" class="img-fluid block">
                    <p class="text-center">
                        <strong><?php echo e($product->name); ?></strong>
                    </p>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ecom-layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tshirt-shop\resources\views/e-commerce/category.blade.php ENDPATH**/ ?>