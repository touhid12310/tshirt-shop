<?php echo $__env->make('ecom-layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-white">
                <div class="container-fluid"> 
                  <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <h4><?php echo e(domainDetail()->title); ?></h4>
                        
                  </a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      
                    </ul>
                    <div class="d-flex">
                      <a class="position-relative" href="<?php echo e(url('/order/cart')); ?>">
                        <i class="fa fa-shopping-cart" style="color: gray; font-size: 1.5em"></i>
                        <span id="top-cart-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                          0
                        </span>
                      </a>
                    </div>
                  </div>
                </div>
              </nav>
        <?php echo $__env->yieldContent('content'); ?>
</div>
<hr>
<?php echo $__env->make('ecom-layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tshirt-shop\resources\views/ecom-layouts/app.blade.php ENDPATH**/ ?>