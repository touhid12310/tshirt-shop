<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('style'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center text-success">Your order is successful. Order no - <?php echo e($order->id); ?> </h3>
            </div>
        </div>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    


    $(document).ready(function() {
        clearlStorage();
        $("#top-cart-count").html(0)
    })
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ecom-layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tshirt-shop\resources\views/e-commerce/order-complete.blade.php ENDPATH**/ ?>