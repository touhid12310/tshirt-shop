<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('style'); ?>
<style>
    .single-cart-item {
        border: 1px solid gray;
    }
    .single-cart-item:not(:last-child) {
        border-bottom: inherit;
    }
    .fa-times {
        cursor: pointer;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="container my-5">
        <div class="row">
            <div class="col-md-6">
                <h4>Your Cart - <span id="itemCounts"></span></h4>
                <div id="cartDetails">

                </div>
            </div>
            <div class="col-md-6">
                <div class="container-fluid">
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                            <h4>&nbsp;</h4>
                            
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div><span class="font-weight-bold">Subtotal</span></div>
                                        <div><span id="subTotal"></span></div>
                                    </div>
                                    <hr class="my-2">
                                    
                                    <div class="d-flex justify-content-between">
                                        <div><span>Shipping &amp; Fees</span></div>
                                        <div><span class="font-italic text-secondary">Calculated at checkout</span></div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3 d-none">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="email">Enter Email for Express Checkout</label>
                                        <input type="email" class="form-control" id="email" placeholder="Email" autocomplete="email">
                                    </div>
                                </div>
                            </div>
                            <div class="d-grid gap-2">
                                <a class="btn btn-primary" href="<?php echo e(route('checkout-page')); ?>">Proceed to Checkout</a>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    

    function changeQty(index, qty) {
        

        var cartItems = pullObjectFromStorage('cartItems')

        let quantity = parseInt(cartItems[index].qty)
        quantity += qty

        if(quantity == 0 || quantity == 1) {
            quantity = 1
            $("#cartMinus").addClass("text-disabled")
        }

        if(quantity > 1) {
            $("#cartMinus").removeClass("text-disabled")
        }
        $(".cartQty").html(quantity)
        cartItems[index].qty = quantity
        pushObjectToStorage('cartItems', cartItems)
        renderCartUi(cartItems)

    }


    $(document).ready(function() {
        var cartItems = pullObjectFromStorage('cartItems')
        $("#itemCounts").html(cartItems.length + " items")
        renderCartUi(cartItems)
    })
    
    function renderCartUi(cartItems) {
        $("#cartDetails").empty();

        let subtotal = 0;
        // Loop through cartItems and create HTML for each item
        cartItems.forEach(function(item, index) {
            subtotal += parseFloat(item.qty) * parseFloat(item.productPrice);

            let singleCartItem = $('<div class="bg-white p-2 single-cart-item">' +
                '<div class="row">' +
                '<div class="col-md-2">' +
                '<img src="' + item.frontImage + '" alt="" style="width: 100%;">' +
                '</div>' +
                '<div class="col-md-8">' +
                '<p class="campaign-name cart-paragraph">' + item.campaignTitle + '</p>' +
                '<p class="product-info cart-paragraph">' + item.productName +'/'+ item.color +'/'+ item.size.toUpperCase() + '</p>' +
                '<div class="my-2">' +
                'Qty: ' +
                '<i onclick="changeQty('+index+', -1)" id="cartMinus" class="text-disabled fa-solid fa-circle-minus" style="cursor: pointer; font-size: 1rem"></i>' +
                '<span class="cartQty px-2" style="font-size: 1rem">' + item.qty + '</span>' +
                '<i onclick="changeQty('+index+', 1)" class="fa-solid fa-circle-plus" style="cursor: pointer; font-size: 1rem"></i>' +
                '</div>' +
                '</div>' +
                '<div class="col-md-2" style="text-align: right;">' +
                '<i class="fa fa-2x fa-times text-danger"></i>' +
                '<p class="product-price cart-paragraph"> $' + item.productPrice + '</p>' +
                '</div>' +
                '</div>' +
                '</div>');

            // Append the created HTML to the #cartDetails div
            $("#cartDetails").append(singleCartItem);
        });

        $("#subTotal").html("$"+subtotal)
    }

    $(document).on("click", ".fa-times", function() {
        // Get the index of the item to be removed
        let indexToRemove = $(this).closest('.single-cart-item').index();

        var cartItems = pullObjectFromStorage('cartItems')
        // Remove the item from cartItems array
        cartItems.splice(indexToRemove, 1);
        pushObjectToStorage('cartItems', cartItems)
        renderCartUi(cartItems)
        
        var newCartItems = pullObjectFromStorage('cartItems')
        $("#top-cart-count").html(newCartItems.length)
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ecom-layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tshirt-shop\resources\views/e-commerce/cart.blade.php ENDPATH**/ ?>